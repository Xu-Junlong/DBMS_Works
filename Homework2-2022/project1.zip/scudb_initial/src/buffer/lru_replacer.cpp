/**
 * LRU implementation
 */
#include "buffer/lru_replacer.h"
#include "page/page.h"

namespace scudb {

    template <typename T> LRUReplacer<T>::LRUReplacer() {
        head = make_shared<Node>();
        tail = make_shared<Node>();
        head->next = tail;
        tail->pre = head;
    }

    template <typename T> LRUReplacer<T>::~LRUReplacer() {}

/*
 * Insert value into LRU
 */
    template <typename T> void LRUReplacer<T>::Insert(const T &value) {
        lock_guard<mutex> lck(myLatch);
        shared_ptr<Node> flag;
        if (map.find(value) != map.end()) {
            flag = map[value];
            shared_ptr<Node> pre = flag->pre;
            shared_ptr<Node> succ = flag->next;
            pre->next = succ;
            succ->pre = pre;
        } else {
            flag = make_shared<Node>(value);
        }
        shared_ptr<Node> fir = head->next;
        flag->next = fir;
        fir->pre = flag;
        flag->pre = head;
        head->next = flag;
        map[value] = flag;
        return;
    }

/* If LRU is non-empty, pop the head member from LRU to argument "value", and
 * return true. If LRU is empty, return false
 */
    template <typename T> bool LRUReplacer<T>::Victim(T &value) {
        lock_guard<mutex> lck(myLatch);
        if (map.empty()) {
            return false;
        }
        shared_ptr<Node> last = tail->pre;
        tail->pre = last->pre;
        last->pre->next = tail;
        value = last->val;
        map.erase(last->val);
        return true;
    }

/*
 * Remove value from LRU. If removal is successful, return true, otherwise
 * return false
 */
    template <typename T> bool LRUReplacer<T>::Erase(const T &value) {
        lock_guard<mutex> lck(myLatch);
        if (map.find(value) != map.end()) {
            shared_ptr<Node> flag = map[value];
            flag->pre->next = flag->next;
            flag->next->pre = flag->pre;
        }
        return map.erase(value);
    }

    template <typename T> size_t LRUReplacer<T>::Size() {
        lock_guard<mutex> lck(myLatch);
        return map.size();
    }

    template class LRUReplacer<Page *>;
// test only
    template class LRUReplacer<int>;

} // namespace scudb